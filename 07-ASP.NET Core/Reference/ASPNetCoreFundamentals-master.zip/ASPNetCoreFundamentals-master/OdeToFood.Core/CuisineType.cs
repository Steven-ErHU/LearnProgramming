﻿namespace OdeToFood.Core
{
  public enum CuisineType
  {
    None,
    Mexican,
    Italian,
    Indian,
    Seafood,
    Greek
  }
}