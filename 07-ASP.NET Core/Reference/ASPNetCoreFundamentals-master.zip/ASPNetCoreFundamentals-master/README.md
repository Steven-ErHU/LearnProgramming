# ASPNetCoreFundamentals
 OdeToFood Pluralsight Course by Scott Allen
