﻿namespace SpaServicesSampleApp.Models
{
    public class Post
    {
        public int PostId { get; set; }
        public string Title { get; set; }
        public string Link { get; set; }
        public string Author { get; set; }
        public int BlogId { get; set; }
    }
}
