---
title: ASP.NET Core Blazor layouts
author: guardrex
description: Learn how to create reusable layout components for Blazor apps.
monikerRange: '>= aspnetcore-3.0'
ms.author: riande
ms.custom: mvc
ms.date: 12/05/2019
no-loc: [Blazor]
uid: blazor/layouts
---
# ASP.NET Core Blazor layouts

By [Rainer Stropek](https://www.timecockpit.com) and [Luke Latham](https://github.com/guardrex)

Some app elements, such as menus, copyright messages, and company logos, are usually part of app's overall layout and used by every component in the app. Copying the code of these elements into all of the components of an app isn't an efficient approach&mdash;every time one of the elements requires an update, every component must be updated. Such duplication is difficult to maintain and can lead to inconsistent content over time. *Layouts* solve this problem.

Technically, a layout is just another component. A layout is defined in a Razor template or in C# code and can use [data binding](xref:blazor/components#data-binding), [dependency injection](xref:blazor/dependency-injection), and other component scenarios.

To turn a *component* into a *layout*, the component:

* Inherits from `LayoutComponentBase`, which defines a `Body` property for the rendered content inside the layout.
* Uses the Razor syntax `@Body` to specify the location in the layout markup where the content is rendered.

The following code sample shows the Razor template of a layout component, *MainLayout.razor*. The layout inherits `LayoutComponentBase` and sets the `@Body` between the navigation bar and the footer:

[!code-razor[](layouts/sample_snapshot/3.x/MainLayout.razor?highlight=1,13)]

In an app based on one of the Blazor app templates, the `MainLayout` component (*MainLayout.razor*) is in the app's *Shared* folder.

## Default layout

Specify the default app layout in the `Router` component in the app's *App.razor* file. The following `Router` component, which is provided by the default Blazor templates, sets the default layout to the `MainLayout` component:

[!code-razor[](layouts/sample_snapshot/3.x/App1.razor?highlight=3)]

To supply a default layout for `NotFound` content, specify a `LayoutView` for `NotFound` content:

[!code-razor[](layouts/sample_snapshot/3.x/App2.razor?highlight=6-9)]

For more information on the `Router` component, see <xref:blazor/routing>.

Specifying the layout as a default layout in the router is a useful practice because it can be overridden on a per-component or per-folder basis. Prefer using the router to set the app's default layout because it's the most general technique.

## Specify a layout in a component

Use the Razor directive `@layout` to apply a layout to a component. The compiler converts `@layout` into a `LayoutAttribute`, which is applied to the component class.

The content of the following `MasterList` component is inserted into the `MasterLayout` at the position of `@Body`:

[!code-razor[](layouts/sample_snapshot/3.x/MasterList.razor?highlight=1)]

Specifying the layout directly in a component overrides a *default layout* set in the router or an `@layout` directive imported from *_Imports.razor*.

## Centralized layout selection

Every folder of an app can optionally contain a template file named *_Imports.razor*. The compiler includes the directives specified in the imports file in all of the Razor templates in the same folder and recursively in all of its subfolders. Therefore, an *_Imports.razor* file containing `@layout MyCoolLayout` ensures that all of the components in a folder use `MyCoolLayout`. There's no need to repeatedly add `@layout MyCoolLayout` to all of the *.razor* files within the folder and subfolders. `@using` directives are also applied to components in the same way.

The following *_Imports.razor* file imports:

* `MyCoolLayout`.
* All Razor components in the same folder and any subfolders.
* The `BlazorApp1.Data` namespace.
 
[!code-razor[](layouts/sample_snapshot/3.x/_Imports.razor)]

The *_Imports.razor* file is similar to the [_ViewImports.cshtml file for Razor views and pages](xref:mvc/views/layout#importing-shared-directives) but applied specifically to Razor component files.

Specifying a layout in *_Imports.razor* overrides a layout specified as the router's *default layout*.

## Nested layouts

Apps can consist of nested layouts. A component can reference a layout which in turn references another layout. For example, nesting layouts are used to create a multi-level menu structure.

The following example shows how to use nested layouts. The *EpisodesComponent.razor* file is the component to display. The component references the `MasterListLayout`:

[!code-razor[](layouts/sample_snapshot/3.x/EpisodesComponent.razor?highlight=1)]

The *MasterListLayout.razor* file provides the `MasterListLayout`. The layout references another layout, `MasterLayout`, where it's rendered. `EpisodesComponent` is rendered where `@Body` appears:

[!code-razor[](layouts/sample_snapshot/3.x/MasterListLayout.razor?highlight=1,9)]

Finally, `MasterLayout` in *MasterLayout.razor* contains the top-level layout elements, such as the header, main menu, and footer. `MasterListLayout` with the `EpisodesComponent` is rendered where `@Body` appears:

[!code-razor[](layouts/sample_snapshot/3.x/MasterLayout.razor?highlight=6)]

## Additional resources

* <xref:mvc/views/layout>
